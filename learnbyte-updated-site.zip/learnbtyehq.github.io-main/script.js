/* =========================================================
   LearnByte — shared site JavaScript
   ========================================================= */

(function () {
    "use strict";

    document.addEventListener("DOMContentLoaded", function () {
        const menuToggle = document.getElementById("menuToggle");
        const navMenu = document.getElementById("navMenu");

        if (menuToggle && navMenu) {
            const navLinks = navMenu.querySelectorAll("a");

            function closeMenu() {
                navMenu.classList.remove("active");
                menuToggle.setAttribute("aria-expanded", "false");
                menuToggle.setAttribute("aria-label", "Open navigation menu");
            }

            function openMenu() {
                navMenu.classList.add("active");
                menuToggle.setAttribute("aria-expanded", "true");
                menuToggle.setAttribute("aria-label", "Close navigation menu");
            }

            menuToggle.addEventListener("click", function (event) {
                event.stopPropagation();
                if (navMenu.classList.contains("active")) {
                    closeMenu();
                } else {
                    openMenu();
                }
            });

            navLinks.forEach(function (link) {
                link.addEventListener("click", closeMenu);
            });

            document.addEventListener("click", function (event) {
                if (!navMenu.contains(event.target) && !menuToggle.contains(event.target)) {
                    closeMenu();
                }
            });

            document.addEventListener("keydown", function (event) {
                if (event.key === "Escape" && navMenu.classList.contains("active")) {
                    closeMenu();
                    menuToggle.focus();
                }
            });

            window.addEventListener("resize", function () {
                if (window.innerWidth > 680) {
                    closeMenu();
                }
            }, { passive: true });
        }

        /* Mark the current primary navigation destination. */
        const currentPath = window.location.pathname.replace(/\\/g, "/").replace(/\/$/, "/index.html");
        document.querySelectorAll(".nav-menu a").forEach(function (link) {
            const href = link.getAttribute("href");
            if (!href || href.startsWith("#") || href.startsWith("http")) return;
            try {
                const linkPath = new URL(href, window.location.href).pathname.replace(/\\/g, "/").replace(/\/$/, "/index.html");
                if (linkPath === currentPath) {
                    link.setAttribute("aria-current", "page");
                    link.classList.add("nav-current");
                }
            } catch (_) {}
        });

        /* Keep the copyright year current. */
        document.querySelectorAll(".footer-bottom p").forEach(function (yearElement) {
            yearElement.textContent = "© " + new Date().getFullYear() + " LearnByte. All rights reserved.";
        });
    });
}());
